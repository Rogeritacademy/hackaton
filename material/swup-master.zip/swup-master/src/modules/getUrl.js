module.exports = function () {
    this.currentUrl = window.location.pathname + window.location.search
}